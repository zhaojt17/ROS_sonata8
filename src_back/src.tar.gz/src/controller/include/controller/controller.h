#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

#include "ros/ros.h"
#include "can_driver/can_receive.h"
#include "can_driver/can_transmit.h"


class controller{

    public: 



    private:


};

#endif 