#ifndef _EXAMPLE_CONTROLLER_H_
#define _EXAMPLE_CONTROLLER_H_

#include "controller/controller.h"

class example_controller :public controller{

public:






private:



};

#endif 