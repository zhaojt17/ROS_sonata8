#!/usr/bin/env python
# coding=utf-8

import rospy
import numpy as np


class Env:
    def __init__(self):
        self.nogui = False

    def reset(self):
        pass

    def step(self):
        pass

